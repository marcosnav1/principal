# Instruções para Deploy do Sistema de Controle de Limpeza Terminal

Este documento fornece instruções detalhadas para realizar o deploy das novas funcionalidades implementadas no Sistema de Controle de Limpeza Terminal.

## Conteúdo do Pacote

Este pacote contém:

1. **Pasta `build`**: Contém a versão compilada e otimizada da aplicação, pronta para deploy
2. **Pasta `documentacao`**: Contém este guia e outros documentos de suporte

## Opções de Deploy

Existem várias opções para publicar a aplicação. Escolha a que melhor se adapta às suas necessidades:

### 1. GitHub Pages

GitHub Pages é uma opção gratuita e fácil para hospedar aplicações estáticas.

1. Crie um repositório no GitHub (ou use um existente)
2. Faça upload da pasta `build` para o repositório
3. Nas configurações do repositório, ative o GitHub Pages:
   - Vá para "Settings" > "Pages"
   - Em "Source", selecione "main" (ou master) e a pasta onde está o conteúdo da build
   - Clique em "Save"
4. Aguarde alguns minutos e sua aplicação estará disponível em `https://[seu-usuario].github.io/[nome-do-repositorio]`

### 2. Netlify

Netlify oferece hospedagem gratuita com recursos avançados.

1. Crie uma conta em [netlify.com](https://www.netlify.com/)
2. Após fazer login, clique em "Add new site" > "Deploy manually"
3. Arraste e solte a pasta `build` na área indicada
4. Aguarde o upload e o deploy
5. Sua aplicação estará disponível em um domínio gerado automaticamente (ex: `https://random-name-123456.netlify.app`)
6. Você pode configurar um domínio personalizado nas configurações do site

### 3. Vercel

Vercel é outra excelente opção para hospedagem de aplicações React.

1. Crie uma conta em [vercel.com](https://vercel.com/)
2. Após fazer login, clique em "Add New" > "Project"
3. Escolha "Upload" e selecione a pasta `build`
4. Clique em "Deploy"
5. Sua aplicação estará disponível em um domínio gerado automaticamente (ex: `https://your-project.vercel.app`)
6. Você pode configurar um domínio personalizado nas configurações do projeto

### 4. Hospedagem Compartilhada Tradicional

Se você já possui um serviço de hospedagem web:

1. Acesse o painel de controle da sua hospedagem
2. Navegue até o gerenciador de arquivos
3. Faça upload de todo o conteúdo da pasta `build` para a pasta pública do seu domínio (geralmente `public_html`, `www` ou `htdocs`)
4. Sua aplicação estará disponível no seu domínio

## Configurações Adicionais

### Para hospedagem tradicional

Se você estiver usando hospedagem compartilhada tradicional, pode ser necessário adicionar um arquivo `.htaccess` na raiz da pasta de upload com o seguinte conteúdo:

```
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteCond %{REQUEST_FILENAME} !-l
  RewriteRule . /index.html [L]
</IfModule>
```

### Verificação após deploy

Após o deploy, acesse a URL da aplicação e verifique:

1. Se a tela de login é exibida corretamente
2. Se é possível fazer login com as credenciais (admin/hospital2025)
3. Se todas as abas estão funcionando, incluindo as novas:
   - Limpezas Excepcionais
   - Dashboard

## Solução de Problemas

### Problema: Tela em branco após o deploy

Verifique se:
- O arquivo `index.html` está na raiz da pasta de deploy
- Todos os arquivos JavaScript e CSS foram carregados corretamente (verifique o console do navegador)
- O serviço de hospedagem suporta aplicações de página única (SPA)

### Problema: Erro 404 ao navegar entre páginas

Como a aplicação usa HashRouter, isso não deveria acontecer. Se ocorrer:
- Verifique se todos os arquivos foram carregados corretamente
- Tente acessar a aplicação com `/#/` no final da URL

## Suporte

Caso encontre dificuldades durante o processo de deploy, entre em contato para obter suporte adicional.
