# Manual do Usuário - Novas Funcionalidades
# Sistema de Controle de Limpeza Terminal

Este manual descreve as novas funcionalidades implementadas no Sistema de Controle de Limpeza Terminal.

## Índice

1. [Aba de Limpezas Excepcionais](#aba-de-limpezas-excepcionais)
2. [Dashboard de Estatísticas](#dashboard-de-estatísticas)

## Aba de Limpezas Excepcionais

A aba de Limpezas Excepcionais permite visualizar e gerenciar todas as limpezas que foram adicionadas fora do cronograma regular.

### Como acessar

1. Faça login no sistema com suas credenciais
2. No menu principal, clique em "Limpezas Excepcionais"

### Funcionalidades disponíveis

#### Visualização de limpezas excepcionais

A tela principal exibe uma tabela com todas as limpezas excepcionais cadastradas, contendo as seguintes informações:
- Setor
- Período
- Dia
- Dia da Semana
- Status
- Responsável
- Data de Execução
- Observações

#### Filtros

Você pode filtrar as limpezas excepcionais por:
- **Setor**: Selecione um setor específico
- **Período**: Filtre por MANHÃ, TARDE ou NOITE
- **Status**: Visualize apenas limpezas Pendentes ou Concluídas

#### Ordenação

É possível ordenar a lista por:
- Data de Execução
- Setor
- Período
- Dia
- Status

#### Ações disponíveis

Para cada limpeza excepcional, você pode:

1. **Editar**: Permite modificar informações como setor, período, dia, etc.
2. **Marcar como Concluído**: Registra a conclusão da limpeza, solicitando o nome do responsável
3. **Excluir**: Remove a limpeza excepcional do sistema (requer confirmação)

## Dashboard de Estatísticas

O Dashboard oferece uma visão completa e detalhada das estatísticas de limpeza terminal.

### Como acessar

1. Faça login no sistema com suas credenciais
2. No menu principal, clique em "Dashboard"

### Resumo Geral

Na parte superior do Dashboard, você encontrará um resumo com:
- **Total de Limpezas**: Número total de limpezas no sistema
- **Concluídas**: Quantidade e percentual de limpezas concluídas
- **Pendentes**: Quantidade e percentual de limpezas pendentes
- **Limpezas Excepcionais**: Quantidade e percentual de limpezas excepcionais

### Gráficos Disponíveis

#### Status das Limpezas
Gráfico de pizza mostrando a proporção entre limpezas concluídas e pendentes.

#### Distribuição por Período
Gráfico de barras mostrando a quantidade de limpezas por período (MANHÃ, TARDE, NOITE).

#### Top 10 Setores
Gráfico de barras horizontais mostrando os 10 setores com maior número de limpezas.

#### Distribuição por Dia da Semana
Gráfico de barras mostrando a quantidade de limpezas por dia da semana.

#### Taxas de Conclusão
Três gráficos mostrando as taxas de conclusão:
- Por Período
- Por Dia da Semana
- Tipo de Limpeza (Programadas vs. Excepcionais)

#### Distribuição por Dia do Mês
Gráfico de linha mostrando a distribuição de limpezas ao longo dos dias do mês.

### Como interpretar os dados

- **Cores verdes** geralmente indicam limpezas concluídas ou taxas positivas
- **Cores amarelas** geralmente indicam limpezas pendentes
- **Percentuais** mostram a proporção em relação ao total
- **Gráficos de barras** permitem comparar quantidades entre diferentes categorias
- **Gráficos de linha** mostram tendências ao longo do tempo

### Dicas de uso

- Utilize o Dashboard para identificar padrões e tendências
- Monitore as taxas de conclusão para avaliar o desempenho
- Identifique setores com maior demanda de limpezas
- Acompanhe a distribuição ao longo da semana para otimizar a alocação de recursos

## Suporte

Caso encontre dificuldades ou tenha dúvidas sobre as novas funcionalidades, entre em contato com o suporte técnico.
